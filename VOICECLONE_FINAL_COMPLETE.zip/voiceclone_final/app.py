from flask import Flask, render_template, request, jsonify, send_file, session
from werkzeug.utils import secure_filename
import os
import sqlite3
import hashlib
from datetime import datetime, timedelta
import uuid
import threading
import time

app = Flask(__name__)
app.secret_key = 'voiceclone_premium_secret_key_2024'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'outputs'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

# Database setup
def init_db():
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  role TEXT DEFAULT 'user',
                  plan_active INTEGER DEFAULT 0,
                  plan_expires TEXT,
                  created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS audio_jobs
                 (id TEXT PRIMARY KEY,
                  user_id INTEGER NOT NULL,
                  script TEXT NOT NULL,
                  language TEXT NOT NULL,
                  speed REAL NOT NULL,
                  reference_file TEXT NOT NULL,
                  output_file TEXT,
                  status TEXT DEFAULT 'processing',
                  duration REAL DEFAULT 0,
                  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                  completed_at TEXT,
                  FOREIGN KEY(user_id) REFERENCES users(id))''')
    
    admin_pass = hashlib.sha256('admin123'.encode()).hexdigest()
    try:
        c.execute("INSERT INTO users (username, email, password, role, plan_active) VALUES (?, ?, ?, ?, ?)",
                 ('admin', 'admin@voiceclone.com', admin_pass, 'admin', 1))
        conn.commit()
    except:
        pass
    
    conn.close()
    print("✅ Database initialized")

init_db()

# Simulated voice cloning (replace with real TTS in production)
def generate_voice_clone(job_id, reference_file, script, language, speed):
    """Simulate voice cloning - Replace with real Coqui TTS"""
    time.sleep(5)  # Simulate processing
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    
    output_file = f"voice_{job_id}.mp3"
    output_path = os.path.join(app.config['OUTPUT_FOLDER'], output_file)
    
    # Create dummy audio file (in production, use real TTS)
    with open(output_path, 'wb') as f:
        f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x02\x00D\xac\x00\x00\x10\xb1\x02\x00\x04\x00\x10\x00data\x00\x00\x00\x00')
    
    duration = len(script) / 10.0
    
    c.execute('''UPDATE audio_jobs 
                 SET status='completed', output_file=?, duration=?, completed_at=? 
                 WHERE id=?''',
             (output_file, duration, datetime.now().isoformat(), job_id))
    conn.commit()
    conn.close()
    
    print(f"✅ Job {job_id} completed")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE username=? AND password=?', (username, password_hash))
    user = c.fetchone()
    conn.close()
    
    if user:
        session['user_id'] = user[0]
        session['username'] = user[1]
        session['role'] = user[4]
        
        return jsonify({
            'success': True,
            'username': user[1],
            'role': user[4],
            'plan_active': user[5] == 1
        })
    
    return jsonify({'success': False, 'error': 'Invalid credentials'}), 401

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    try:
        conn = sqlite3.connect('voiceclone.db')
        c = conn.cursor()
        c.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                 (username, email, password_hash))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except:
        return jsonify({'success': False, 'error': 'Username or email exists'}), 400

@app.route('/api/user-info')
def user_info():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE id=?', (session['user_id'],))
    user = c.fetchone()
    conn.close()
    
    if user:
        plan_active = user[5] == 1
        if user[6]:
            expires = datetime.fromisoformat(user[6])
            if datetime.now() > expires:
                plan_active = False
        
        return jsonify({
            'username': user[1],
            'email': user[2],
            'role': user[4],
            'plan_active': plan_active,
            'plan_expires': user[6]
        })
    
    return jsonify({'error': 'User not found'}), 404

@app.route('/api/generate', methods=['POST'])
def generate():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    # Check plan
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('SELECT plan_active, plan_expires FROM users WHERE id=?', (session['user_id'],))
    user = c.fetchone()
    
    if not user or user[0] != 1:
        conn.close()
        return jsonify({'error': 'No active plan. Contact admin to activate.'}), 403
    
    if user[1]:
        expires = datetime.fromisoformat(user[1])
        if datetime.now() > expires:
            conn.close()
            return jsonify({'error': 'Plan expired. Contact admin.'}), 403
    
    # Get form data
    script = request.form.get('script')
    language = request.form.get('language', 'en')
    speed = float(request.form.get('speed', 1.0))
    reference_audio = request.files.get('reference_audio')
    
    if not script or not reference_audio:
        conn.close()
        return jsonify({'error': 'Script and reference audio required'}), 400
    
    # Save files
    job_id = str(uuid.uuid4())[:12]
    ref_filename = secure_filename(f"ref_{job_id}_{reference_audio.filename}")
    ref_path = os.path.join(app.config['UPLOAD_FOLDER'], ref_filename)
    reference_audio.save(ref_path)
    
    # Create job
    c.execute('''INSERT INTO audio_jobs 
                 (id, user_id, script, language, speed, reference_file, status) 
                 VALUES (?, ?, ?, ?, ?, ?, 'processing')''',
             (job_id, session['user_id'], script, language, speed, ref_filename))
    conn.commit()
    conn.close()
    
    # Start background processing
    thread = threading.Thread(target=generate_voice_clone, 
                             args=(job_id, ref_path, script, language, speed))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'success': True,
        'job_id': job_id,
        'message': 'Voice generation started. Will complete in 30-45 seconds.'
    })

@app.route('/api/job/<job_id>')
def job_status(job_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('SELECT * FROM audio_jobs WHERE id=? AND user_id=?', (job_id, session['user_id']))
    job = c.fetchone()
    conn.close()
    
    if not job:
        return jsonify({'status': 'processing'})
    
    return jsonify({
        'status': job[7],
        'output_file': job[6],
        'duration': job[8],
        'download_url': f'/api/download/{job[6]}' if job[6] else None
    })

@app.route('/api/history')
def history():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('''SELECT id, script, language, speed, output_file, status, duration, created_at 
                 FROM audio_jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 50''',
             (session['user_id'],))
    jobs = c.fetchall()
    conn.close()
    
    history = []
    lang_names = {
        'en': 'English', 'es': 'Spanish', 'fr': 'French', 'de': 'German',
        'it': 'Italian', 'pt': 'Portuguese', 'pl': 'Polish', 'tr': 'Turkish',
        'ru': 'Russian', 'nl': 'Dutch', 'cs': 'Czech', 'ar': 'Arabic',
        'zh-cn': 'Chinese', 'ja': 'Japanese', 'ko': 'Korean', 
        'hu': 'Hungarian', 'hi': 'Hindi', 'ur': 'Urdu'
    }
    
    for job in jobs:
        if job[5] == 'completed':
            history.append({
                'id': job[0],
                'script': job[1],
                'language': job[2],
                'language_name': lang_names.get(job[2], job[2]),
                'speed': job[3],
                'output_file': job[4],
                'duration': job[6],
                'created_at': job[7],
                'download_url': f'/api/download/{job[4]}'
            })
    
    return jsonify({'history': history})

@app.route('/api/download/<filename>')
def download(filename):
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True, download_name=filename)
    
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/logout')
def logout():
    session.clear()
    return jsonify({'success': True})

# Admin routes
@app.route('/api/admin/users')
def admin_users():
    if 'role' not in session or session['role'] != 'admin':
        return jsonify({'error': 'Admin only'}), 403
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('SELECT id, username, email, plan_active, plan_expires, created_at FROM users WHERE role="user"')
    users = c.fetchall()
    conn.close()
    
    return jsonify({'users': [
        {'id': u[0], 'username': u[1], 'email': u[2], 
         'plan_active': u[3], 'plan_expires': u[4], 'created_at': u[5]}
        for u in users
    ]})

@app.route('/api/admin/activate-plan', methods=['POST'])
def activate_plan():
    if 'role' not in session or session['role'] != 'admin':
        return jsonify({'error': 'Admin only'}), 403
    
    data = request.json
    user_id = data.get('user_id')
    months = data.get('months', 1)
    
    expires = (datetime.now() + timedelta(days=30 * months)).isoformat()
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    c.execute('UPDATE users SET plan_active=1, plan_expires=? WHERE id=?', (expires, user_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': f'Plan activated for {months} months'})

@app.route('/api/admin/stats')
def admin_stats():
    if 'role' not in session or session['role'] != 'admin':
        return jsonify({'error': 'Admin only'}), 403
    
    conn = sqlite3.connect('voiceclone.db')
    c = conn.cursor()
    
    c.execute('SELECT COUNT(*) FROM users WHERE role="user"')
    total_users = c.fetchone()[0]
    
    c.execute('SELECT COUNT(*) FROM users WHERE plan_active=1')
    active_plans = c.fetchone()[0]
    
    c.execute('SELECT COUNT(*) FROM audio_jobs')
    total_jobs = c.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'total_users': total_users,
        'active_plans': active_plans,
        'total_jobs': total_jobs
    })

if __name__ == '__main__':
    print("=" * 60)
    print("🎙️  VOICECLONE PREMIUM - SERVER STARTING")
    print("=" * 60)
    print("✅ Database initialized")
    print("✅ Upload folder created")
    print("✅ Output folder created")
    print("")
    print("🌐 Server running at: http://localhost:5000")
    print("👤 Admin login: admin / admin123")
    print("")
    print("📱 Contact: Saniyal - 03278445763")
    print("💬 WhatsApp: https://wa.me/923278445763")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5000)
